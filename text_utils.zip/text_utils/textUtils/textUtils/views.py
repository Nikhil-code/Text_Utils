# I have created this file - Nikhil
from django.http import HttpResponse
from django.shortcuts import render


def index(request):
    # return HttpResponse('''<h1>Hello Nikhil</h1>
    # <a href="about">about</a>''')
    # params = {"name": "Nikhil", "Place": "Milky-way"}
    return render(request, 'index.html')


def about(request):
    return HttpResponse("About, Hello Nikhil")


def analyze(request):
    # Getting the text in terminal
    dj_text = request.POST.get('text', 'default')

    # Check checkbox values
    remove_punctuation = request.POST.get('removepunc', 'off')
    full_caps = request.POST.get('fullcaps', 'off')
    newline_remove = request.POST.get('newlineremove', 'off')
    ex_space_remove = request.POST.get('extraspaceremove', 'off')
    char_count = request.POST.get('charactercount', 'off')

    params = ""
    if remove_punctuation == "on":
        analyzed = ""
        punctuations = '''!()-[]{};:'"\<>/?@#$%^&*_~'''
        for char in dj_text:
            if char not in punctuations:
                analyzed = analyzed + char
        params = {"purpose": "Remove Punctuations", "analyze_text": analyzed}
        dj_text = analyzed

    if full_caps == "on":
        analyzed = ""
        for char in dj_text:
            analyzed = analyzed + char.upper()
        params = {"purpose": "Uppercase Transformation", "analyze_text": analyzed}
        dj_text = analyzed

    if newline_remove == "on":
        analyzed = ""
        for char in dj_text:
            if char != "\n" and char != "\r":
                analyzed = analyzed + char
        params = {"purpose": "Remove New Line", "analyze_text": analyzed}
        dj_text = analyzed

    if ex_space_remove == "on":
        analyzed = ""
        for index1, char in enumerate(dj_text):
            if dj_text[index1] == " " and dj_text[index1+1] == " ":
                pass
            else:
                analyzed = analyzed + char
        params = {"purpose": "Extra-space remove operation", "analyze_text": analyzed}
        dj_text = analyzed

    if char_count == "on":
        analyzed = ""
        for char in dj_text:
            count_result = len(char)
            analyzed = analyzed + str(count_result)
            print(analyzed)
        params = {"purpose": "Count characters", "analyze_text": analyzed}

    if remove_punctuation != "on" and full_caps != "on" and newline_remove != "on" and ex_space_remove != "on" and char_count != "on":
        return HttpResponse("Error")

    return render(request, 'analyze.html', params)


# def show_txt(request):
#     with open("F:/Coding/Python/Web Development/Django/temp1.txt", "r") as f:
#         show_text = f.read()
#         # print(show_text)
#         return HttpResponse(show_text)
